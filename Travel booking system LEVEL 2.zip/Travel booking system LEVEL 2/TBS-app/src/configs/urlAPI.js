const URL_API = 'http://localhost:1010/'
// const URL_API = 'https://api.cravelio.com/'

export default URL_API