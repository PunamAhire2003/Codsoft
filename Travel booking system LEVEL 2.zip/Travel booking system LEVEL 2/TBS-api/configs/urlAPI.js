// const URL_API = 'http://localhost:1010/'
const URL_API = 'https://api.cravelio.com/'

module.exports = URL_API