// const URL_APP = 'http://localhost:3000/'
const URL_APP = 'https://www.cravelio.com/'

module.exports = URL_APP